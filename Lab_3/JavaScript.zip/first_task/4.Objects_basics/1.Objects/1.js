let user = {};
user.name = "Jonh";
user.surname = "Smith";
user.name = "Pete";
delete user.name;