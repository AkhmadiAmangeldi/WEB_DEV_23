def sorta_sum(a, b):
  if 10 <= a + b < 20:
    return 20
  return a + b