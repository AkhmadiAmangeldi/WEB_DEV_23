def double_char(str):
  result = ''
  for char in str:
    result += char * 2
  return result  