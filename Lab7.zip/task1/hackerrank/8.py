#swap case problem

s = input()
s = s.swapcase()
print(s)