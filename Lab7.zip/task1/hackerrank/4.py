a = int(input())
b = int(input())

print(int(a/b))

print(a/b)
