first = input()
last = input()

def print_full_name(fname, lname):
    print("Hello " + first + " " + last + "! You just delved into python.")

print_full_name(first, last)