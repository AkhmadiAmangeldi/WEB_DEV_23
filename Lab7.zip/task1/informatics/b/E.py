a = int(input("first number: "))
b = int(input("second number: "))

if a > b:
    print(1)
elif a < b:
    print(2)
else:
    print(0)