a = int(input("first number: "))
b = int(input("second number: "))

if a > b:
    print(a)
else:
    print(b)