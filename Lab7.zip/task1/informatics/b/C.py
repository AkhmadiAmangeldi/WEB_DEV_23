a = int(input("Student's answer: "))
b = int(input("System's amswer: "))

if b == 1 and a == 1:
    print("YES")
elif b == 1 and a != 1:
    print("NO")
else:
    print("YES")