x = int(input())

if x > 0:
    print(1)
elif x < 0:
    print(-1)
else:
    print(0)