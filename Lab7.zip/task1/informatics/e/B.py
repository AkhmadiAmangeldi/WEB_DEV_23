a = int(input())
n = int(input())

def doublePower(a, n):
    print(a**n)

doublePower(a, n)
