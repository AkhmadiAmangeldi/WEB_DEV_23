def findMin(a):
    print(min(a))

arr = []

for i in range(4):
    n = int(input())
    arr.append(n)

findMin(arr)