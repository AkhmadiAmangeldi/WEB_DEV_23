n = int(input())

while n % 2 == 0 and n != 0:    
    n = n / 2;
if n > 1:
    print("NO")

else:
    print("YES")