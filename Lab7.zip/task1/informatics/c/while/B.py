n = int(input(("enter the number: ")))

i = 2
while n % i != 0:
    i += 1
else:
    print(i)