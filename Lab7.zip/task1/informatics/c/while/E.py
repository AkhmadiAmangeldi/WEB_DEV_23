n = int(input())

i = 1
k = 0

while i < n:
    i = i * 2
    k += 1

print(k)