sum = 0

for i in range(100):
    
    n = int(input())
    sum = sum + n

print("sum is:", sum) 