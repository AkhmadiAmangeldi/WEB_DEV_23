zeros = 0
n = int(input())

for i in range(n):
    
    x = int(input())
    if x == 0: 
        zeros = zeros + 1

print(zeros)
