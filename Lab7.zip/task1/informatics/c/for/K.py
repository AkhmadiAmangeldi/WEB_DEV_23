sum = 0
n = int(input())

for i in range(n):
    
    x = int(input())
    sum = sum + x

print("sum is:", sum) 