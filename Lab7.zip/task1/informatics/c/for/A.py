a = int(input("first number: "))
b = int(input("second number: "))

for i in range(a, b):

    if i % 2 == 0:
        print(i, end=" ")
