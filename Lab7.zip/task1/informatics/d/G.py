n = int(input())
arr = []


for i in range(n):
    ele = int(input())
    arr.append(ele)

arr.reverse()
print(arr)