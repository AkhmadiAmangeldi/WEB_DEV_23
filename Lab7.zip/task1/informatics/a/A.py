import math

print("hello")
a = int(input("Vvedite 1 katet: "))
b = int(input("Vvedite 2 katet: "))
print(math.sqrt(a**2 + b**2))