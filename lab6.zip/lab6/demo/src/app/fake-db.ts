import {Album} from "./models";

export const ALBUMS: Album[] = [
  {id:1, title:'title 1'},
  {id:2, title:'title 2'},
  {id:3, title:'title 3'},
  {id:4, title:'title 4'},
]

